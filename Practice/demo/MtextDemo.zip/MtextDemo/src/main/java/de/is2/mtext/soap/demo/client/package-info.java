@javax.xml.bind.annotation.XmlSchema(namespace = "http://omAdapter.bayerische.kwsoft.de/")
package de.is2.mtext.soap.demo.client;
